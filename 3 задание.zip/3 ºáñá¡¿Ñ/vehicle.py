# ----------------------------------------------
import random


class Vehicle:
    def __init__(self):
        self.fuelCapacity = 0
        self.fuelConsumption = 0



    def ReadStrArray(self, strArray, i):
        pass

    def Print(self):
        pass

    def Write(self, fileToWrite):
        pass

    def Distance(self):
        pass
